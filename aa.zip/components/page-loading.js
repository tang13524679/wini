import Loading from '@/components/loading';

export default function PageLoading() {
    return (
        <div className="grid place-content-center" style={{ height: '80vh' }}>
            <Loading />
        </div>
    );
}
