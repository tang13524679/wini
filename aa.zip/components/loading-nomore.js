import { t } from '@/utils/translate';

export default function LoadingNoMore() {
    return <div className="text-center clWhite30 my-4">- {t('noMore')} -</div>;
}
